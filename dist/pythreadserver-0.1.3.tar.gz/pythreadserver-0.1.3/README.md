# About
pythreadserver is a python socket-based multi-threaded server package designed for simple server systems with event based handling calls.
---
# Documentation
[docs.md](docs.md)

