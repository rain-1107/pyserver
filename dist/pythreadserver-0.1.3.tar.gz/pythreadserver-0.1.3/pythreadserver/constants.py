BUFFER_SIZE: int = 512

# Default ports for each connection
PORT_C_TO_S: int = 30000
PORT_S_TO_C: int = 40000
